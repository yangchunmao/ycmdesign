
SAP Java Connector 3.0.9
________________________


General
-------

This archive contains JCo 3.0.9.


Installation
------------

Uncompress the archive into an arbitrary directory <sapjco-install-path>.

Load <sapjco-install-path>/javadoc/intro.html into your browser and follow
the description under the link Installation.


Thanks for using JCo.


